<?php
/**
 * Loads theme lib.
 *
 * @package  WordPress
 * @subpackage  Gelato\Theme
 */

 namespace Gelato\Theme;

 // Composer autoload. Enable when composer is set.
require_once __DIR__ . '/vendor/autoload.php';

/**
 * Main Application class
 */
 final class App {

  /**
	 * Assets instance.
   * Includes all styles enqueuing.
	 *
	 * @var Assets
	 */
	private $assets;

  /**
	 * Config instance.
	 *
	 * @var Config
	 */
	private $config;

  /**
	 * Full Site Editing instance.
	 *
	 * @var FullSiteEditing
	 */
	private $fse;

	/**
	 * Style Book instance.
	 *
	 * @var StyleBook
	 */
	private $stylebook;

  /**
	 * Class constructor.
	 */
	public function __construct() {

        $this->config      = new Config();
        $this->assets      = new Assets();
        $this->fse         = new FullSiteEditing();
				$this->stylebook   = new StyleBook();

    }
 }

 // Start the theme app.
 new App();
