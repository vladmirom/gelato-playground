<?php
/**
 * Style Book page setup.
 *
 * @package WordPress
 * @subpackage  Gelato\Theme
 */

 namespace Gelato\Theme;

/**
 * Common theme configs.
 */
class StyleBook {

  /**
	 * Constructs the initial class.
   *
   * @since Valve 1.0
   * @return void
	 */
	public function __construct() {

		// Actions.
		add_action( 'after_switch_theme', array( $this, 'stylebook_page_setup' ) );

	}

	/**
	 * Sets the Style Book page that is accessible on the Front-End.
	 *
	 * @since Valve 1.0
	 * @return int|null
	 */
	public function stylebook_page_setup() {
		// Define the page title and content.
		$page_title = 'Style Book';
		$page_content = '';
		$custom_template_path = 'style-book.html';

    // Check if the page already exists
		$page_check = get_page_by_path($page_title, OBJECT, 'page');

		if (!isset($page_check->ID)) {
			// Create page array
			$new_page = array(
					'post_title'   => $page_title,
					'post_content' => $page_content,
					'post_status'  => 'publish',
					'post_type'    => 'page',
			);

			// Insert the page into the database.
			$page_id = wp_insert_post($new_page);
			// error_log(print_r( $page_id, 1));

			if ($page_id) {
				// Assign the page template
				update_post_meta($page_id, '_wp_page_template', $custom_template_path);

				error_log(print_r( 'Page created: ' . $page_id, 1));
				error_log(print_r( 'Template of the page is: ' . get_page_template_slug($page_id), 1));
			}
		}
	}
}
