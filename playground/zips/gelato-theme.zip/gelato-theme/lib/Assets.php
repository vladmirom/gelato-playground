<?php
/**
 * Theme asset handling.
 *
 * @package WordPress
 * @subpackage  Gelato\Theme
 */

 namespace Gelato\Theme;

/**
 * Assets class.
 *
 * Enque global theme styles
 * Enque block styles
 */
class Assets {

  /**
	 * Constructs the initial class.
	 */
	public function __construct() {

				add_action( 'wp_enqueue_scripts', array( $this, 'setup_scripts_styles' ) );
        add_action( 'init', array( $this, 'enqueue_theme_block_styles' ) );

    }

    /**
     * Enqueue global scripts and styles.
     *
     * @since Gelato 1.0
     * @return void
     */
		public function setup_scripts_styles() {

			error_log(print_r(get_template_directory_uri() . '/assets/styles/main.css', true));
			// Enqueue main styles.
			wp_enqueue_style (
				'theme-global-styles',
				get_template_directory_uri() . '/assets/styles/main.css',
				array(),
				wp_get_theme( get_template() )->get( 'Version' )
			);

			// Enqueue main scripts.
			wp_enqueue_script (
				'theme-global-scripts',
				get_template_directory_uri() . '/assets/scripts/main.js',
				array(),
				wp_get_theme( get_template() )->get( 'Version' )
			);

		}

    /**
     * Enqueue block stylesheets.
     *
     * @since Gelato 1.0
     * @return void
     */
    public function enqueue_theme_block_styles() {
        wp_enqueue_block_style(
            'core/buttons',
            array(
                'handle' => 'theme-buttons-styles',
                'src'    => get_template_directory_uri() . '/assets/styles/blocks/buttons.css',
                'ver'    => wp_get_theme()->get('Version'),
                'path'    => get_template_directory_uri() . '/assets/styles/blocks/buttons.css',
            )
        );

        wp_enqueue_block_style(
            'core/group',
            array(
                'handle' => 'theme-group-styles',
                'src'    => get_template_directory_uri() . '/assets/styles/blocks/group.css',
                'ver'    => wp_get_theme()->get('Version'),
                'path'    => get_template_directory_uri() . '/assets/styles/blocks/group.css',
            )
        );
    }
}
