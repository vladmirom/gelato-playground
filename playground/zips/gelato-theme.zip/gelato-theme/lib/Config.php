<?php
/**
 * Common theme Configs.
 *
 * @package WordPress
 * @subpackage  Gelato\Theme
 */

 namespace Gelato\Theme;

/**
 * Common theme configs.
 */
class Config {

  /**
	 * Constructs the initial class.
   *
   * @since Gelato 1.0
   * @return void
	 */
	public function __construct() {

		// Actions.
		add_action( 'after_setup_theme', array( $this, 'load_theme_textdomain' ), 100 );
	}

	/**
	 * Load translation for the theme.
	 *
	 * @since Gelato 1.0
	 * @return void
	 */
	public function load_theme_textdomain() {
      load_theme_textdomain( 'valve-theme', get_template_directory() . '/assets/languages' );
	}
}
