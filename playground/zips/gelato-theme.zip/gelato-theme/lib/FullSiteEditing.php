<?php
/**
 * Configs for WordPress FSE.
 *
 * @package WordPress
 * @subpackage  Gelato\Theme
 */

 namespace Gelato\Theme;

/**
 * FSE theme configs.
 */
class FullSiteEditing {

  /**
	 * Constructs the initial class.
	 */
	public function __construct() {

		// Filters.
		add_filter( 'block_categories_all', array( $this, 'theme_block_category' ) );
		add_filter( 'block_editor_settings_all', array( $this, 'theme_disable_font_library_ui' ) );

		// Actions.
		add_action( 'init', array( $this, 'theme_register_blocks' ) );
		add_action( 'init', array( $this, 'theme_register_pattern_categories' ) );
		add_action( 'init', array( $this, 'theme_register_block_styles' ) );

	}

	/**
	 * Register block categories.
	 *
	 * https://developer.wordpress.org/reference/hooks/block_categories_all
	 *
	 * @since Gelato 1.0
	 * @return array $block_categories of post.
	 */
	public function theme_block_category( $block_categories ) {

		$args = array(
				'slug' => 'valve-blocks',
				'title' => __('Valve Blocks', 'gelato-theme'),
				'icon'  => 'heart',
		);

		array_unshift( $block_categories, $args );

		return $block_categories;
	}

	/**
	 * Register custom blocks.
	 *
	 * https://developer.wordpress.org/reference/functions/register_block_type/
	 *
	 * @since Gelato 1.0
	 * @return void
	 */
	public function theme_register_blocks() {
			register_block_type( get_template_directory() . '/blocks/build/example' );
	}

	/**
	 * Register pattern categories.
	 *
	 * https://developer.wordpress.org/reference/functions/register_block_pattern_category/
	 *
	 * @since Gelato 1.0
	 * @return void
	 */
	public function theme_register_pattern_categories() {

			register_block_pattern_category(
					'teasers',
					array(
							'label'       => _x( 'Teasers', 'Block pattern category', 'gelato-theme' ),
							'description' => __( 'A collection of different teaser variations.', 'gelato-theme' ),
					)
			);

			register_block_pattern_category(
					'columned-content',
					array(
							'label'       => _x( 'Columned content', 'Block pattern category', 'gelato-theme' ),
							'description' => __( 'A collection of full columned content layouts.', 'gelato-theme' ),
					)
			);

			register_block_pattern_category(
				'style-book',
				array(
						'label'       => _x( 'Style book', 'Block pattern category', 'gelato-theme' ),
						'description' => __( 'Style book patterns for theme development.', 'gelato-theme' ),
				)
		);
	}

	/**
	 * Register custom block styles.
	 *
	 * These style variations appears in block options.
	 *
	 * @since Gelato 1.0
	 * @return void
	 */
	function theme_register_block_styles() {
		// Register secondary button style variation for the Button block.
		register_block_style(
				'core/button',
				array(
				'name'  => 'secondary',
				'label' => __( 'Secondary', 'gelato-theme' ),
				)
		);
		// Register secondary outline button style variation for the Button block.
		register_block_style(
		'core/button',
				array(
				'name'  => 'secondary-outline',
				'label' => __( 'Secondary Outline', 'gelato-theme' ),
				)
		);
	}

  /**
	 * Hides Font Manager so fonts can't be removed or added.
	 *
	 * @since Gelato 1.0
	 * @return $editor_settings
	 */
	public function theme_disable_font_library_ui( $editor_settings ) {
		$editor_settings['fontLibraryEnabled'] = false;
		return $editor_settings;
	}
}
