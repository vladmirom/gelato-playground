# Valve Custom Blocks

Valve WordPress Starter Theme suports registration of custom blocks. All custom blocks are located in `blocks/src` folder. Starter theme contains Example custom block. In order to add your custom block, use this simple instruction:

1. **In terminal**:
    - Run `cd theme/blocks/src`.
    - Switch to node 20 if possible (`nvm use 20`). The packages that are to be installed require node 20. 
    - Run `npx @wordpress/create-block@latest --no-plugin`.
    - It might notify that "Minimum system requirements not met!", proceed with yes.
    - From 2 options select `dynamic`.
    - Add a block slug, eg: `carousel`.
    - Add a block namespace: `valve`.
    - Add a block title, eg: `Carousel`.
    - Add short description, eg: `The block to display a slider.`.
    - Dashicon, can leave it optional: press enter.
    - Select block category/keywords, eg: `text`.
    - After the block is created, run `cd theme/blocks` and run two commands. 
        - First install npm packages: `npm install`. Otherwise, the command `npm start` will not be found. This command should be run only once in the beginning of the project.
        - Second run the compiler: `npm start`. It will run the compiler for all existing blocks. 

2. **Check that the build folder (/blocks/build/carousel) contains carousel folder with compiled files.**

3. **Register custom blocks.**
    - Open `theme/lib/FullSiteEditing.php` and find `valve_register_blocks()` function.
    - Add newly created block in this function, eg: `register_block_type( get_template_directory() . '/blocks/build/carousel' );`.

4. **Edit the category/keywords.**
    - Open `theme/blocks/custom-block/block.json` and find `"category"`.
    - Add change value `text` to `valve-blocks`, eg: `"category": "valve-blocks",` (the name of category can be found in `theme/lib/FullSiteEditing.php` file in `valve_block_category()` function). 

## Compilation

All the required processes with compilation, minimization, etc., are done automatically when you run the `npm start`, or `npm run build` commands in **`/blocks`** directory. There is no need to run these commands in each block folder separately. In order to be sure that your code has compiled, check the `blocks/build` folder.

## Editing and developing a custom block

The main files to edit are:
- `block.json` - similar to theme.json, configures the available features in editor.
- `render.php` - front-end code mostly. This is what website users would see when the block is used.
- `edit.js` - react based js, which is used to show the block in the editor. 
- `style.scss` - styling of the block for both front-end and editor.
- `edit.scss` - styling of the block only for editor. Can be removed if not used.

## Dealing with Example block

When you have created a block of your own, you don't need Example block. Remove it in 2 places:

1. Open `theme/lib/FullSiteEditing.php` and remove `register_block_type( get_template_directory() . '/blocks/build/example' );` from  `valve_register_blocks()` function. 
2. Open `blocks/src/` folder and simply remove `example` folder. If the script (`npm start`) is running in blocks folder, the `example` folder will be removed automatically from `blocks/build`, otherwise run `npm start`, or `npm run build`.
