# Fonts and Typography in theme

&#9200; Estimated time of completion: 10-15 minutes.

Custom project fonts are located in `assets/fonts` folder. Even if these are Google Fonts, it's better for performance to load files and set them up in theme, then load fonts from theme. 

**Update custom fonts**:
  1. Load font files to `assets/fonts` folder.
  2. Update fonts in `theme.json` with the paths to the files uploaded to `assets/fonts` folder.
  3. Check in stylebook https://yourwebsite.com/style-book that correct fornts were applied.

**Set up custom typography**:
  1. The base font size is set in `asets/styles/common/global.css` on [line 9](/assets/styles/common/global.css#L9). It is used to generate all rems in the project, therefore, it is wise to check and correct it first.
  2. Open `theme.json` and edit `settings.typography.fontSizes`. These font sizes would appear in block editor. At the same time font-size presets are generated that can be used in css.
  3. Headings sizes are set in `theme.json` and can be edited in `styles.elements`. Use presets, generated in step 2. 
