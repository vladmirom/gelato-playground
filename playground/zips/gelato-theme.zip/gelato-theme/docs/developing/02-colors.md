# Colors in theme

&#9200; Estimated time of completion: 10 minutes. 

Colors are set to have set names for easier. The names were set to be in a sequence: `Primary, Secondary, Tertiary, Quaternary, Quinary, Senary`. Keeping the names of the colors the same and adding different values would save development time, otherwise, all preset colors should be changed everywhere in the files.

**Update custom colors**:
  1. Open `theme.json` and edit `settings.colors`.
  2. In order to remove default duotone, add `"defaultDuotone": false,`.
  3. In order to remove default color palette, add `"defaultPalette": false,`.
  4. In order to remove default color palette, add `"defaultPalette": false,`.
  5. Update colors in `settings.colors.palette` to your custom colors. WordPress will generate color presets by the formula: `--wp--preset--color--` + the selected color slug. EG: `--wp--preset--color--black` and in css it could be used as: `var(--wp--preset--color--black)`.
  6. Check in stylebook https://yourwebsite.com/style-book that correct colors were set.


**Update custom gradients**:
  1. Open `theme.json` and edit `settings.colors`.
  2. In order to remove default gradients, add `"defaultGradients": false,`.
  3. Update gradients in `settings.colors.gradients` to your custom gradients. WordPress will generate gradient presets by the formula: `--wp--preset--gradient--` + the selected gradient slug. EG: `--wp--preset--gradient--blue-to-purple-to-orange` and in css it could be used as: `var(--wp--preset--gradient--blue-to-purple-to-orange)`.
  4. Check in stylebook https://yourwebsite.com/style-book that correct gradients were set.
