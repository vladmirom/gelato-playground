# Valve WordPress Starter Theme

Welcome to the WordPress Starter Theme with Full Site Editing (FSE) support. This theme is designed to provide a solid foundation for building custom WordPress themes with the new Full Site Editing capabilities.

> **_NOTE:_** The theme can be used, but it is still work in progress. Upcoming updates:
> 1. Adding asset building. And correctly equeue the files and js to load in editor styles.
> 2. Refined php: Look through all php (functions.php, /lib), clean up.
> 3. Coding standars, linting and testing. 
> 4. Correct use of textdomain and namesacing, so user could just search and replace (Setup composer script).

## Table of Contents
- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Usage](#usage)
- [Customization](#customization)
- [License](#license)

## Features

- **Full Site Editing**: Leverage the power of the new FSE features in WordPress.
- **Block-Based Theme**: Built entirely using blocks, providing a modern and flexible approach to theme development.
- **Responsive Design**: Fully responsive and mobile-friendly out of the box.
- **Lightweight and Fast**: Optimized for performance with minimal bloat.
- **Customizable**: Easily customize through the WordPress Block Editor and theme.json settings.

## Requirements

- **WordPress**: Version 6.5 or higher
- **PHP**: Version 8.1 or higher

## Installation

1. **Download the Theme**:
    - **Note**: Do not clone the repository to avoid removing git files later on.
    - Download the ZIP file and extract it to your `wp-content/themes` directory.
    - For Valve's specific setup, extract theme to `app/web/app/themes` directory.

2. **Activate the Theme**:
    - Go to the WordPress admin dashboard.
    - Navigate to Appearance > Themes.
    - Find the "Valve Starter Theme" and click Activate.

3. **Make project based Theme editions**:
    - Rename the `gelato-theme` folder to the project based name. EG: `projectname-theme`.
    - Search and replace `gelato-theme` in theme folder with your project name for the correct theme translations. EG: `gelato-theme` --> `projectname-theme`.
    - Search and replace `gelato-theme` in theme folder with your project name to correct the slugs in your theme. EG: `gelato-theme` --> `projectname-theme`.
    - Search and replace `Gelato` in theme folder with your project namespace. EG: `Gelato` --> `ProjectName`.
    - Update composer.json file's description (**Optional**):
    	```
      {
        "name": "projectname-theme",
        "description": "A block theme by for Project Name project.",
        "homepage": "https://github.com/valvebranding/project",
        "issues": "https://github.com/valvebranding/project/issues",
      }
      ```
    - Run `composer update`, so the namespace path that we changed in the composer.json is applied.
    - Open the theme/styles.css to update theme information. EG:
      ```
      /*
        Theme Name: Project Name Theme
        Author: Valve Branding Oy
        Author URI: https://valve.fi
        Description: A block theme for Project Name project.
        Text Domain: projectname-theme
      */
      ```
    - Replace a screenshot (**Optional**).

## Usage

### Customization

- **Site Editor**:
    - Navigate to Appearance > Editor.
    - Use the Site Editor to customize your site's global styles, templates, and template parts.

- **Block Patterns**:
    - Utilize predefined block patterns to quickly add complex layouts to your pages and posts.

- **Blocks Styles**:
    - Customize colors, typography, and spacing through the available options of each block.

### Developing with the Theme

- **Global Styling**
    1. Font families and typography are defined in `theme.json`. See the detailed instruction how to use your custom fonts and sizes [here](/docs/developing/01-fonts-typography.md).
    2. Colors and gradients are set in `theme.json`. The detailed instruction can be found [here](/docs/developing/02-colors.md.md).

- **Theme.json**:
    - **Global Settings**:
        - **Colors**: Define a color palette and gradients for use throughout the theme. This includes custom colors, theme colors, and gradients.
        - **Typography**: Set global font families, font sizes, line heights, and font weights. It's better to use font files and upload them to `assets/fonts` folder, instead embedding Google Fonts using a link.
        - **Spacing**: Configure spacing units for margins and padding, and define custom spacing sizes.
        - **Layout**: Control global layout settings like content width and wide width.
    - **Styles**:
        - **Global Styles**: Apply global styles that affect all blocks, such as colors, typography, and spacing.
        - **Block-Level Styles**: Customize the appearance of individual blocks. Each block type can have its own set of styles defined, which might include specific colors, font sizes, alignments, and other styling properties.
    - **Custom Templates**:
        - Define custom templates for posts, pages, and other post types. This allows for specific layouts and designs for different types of content.
    - **Custom Patterns**:
        - Register custom block patterns that can be used to create consistent and reusable content layouts.

- **Templates and Template Parts**:
    - Edit existing templates and template parts or create new ones within the `templates` and `parts` (footer and header) directories.

- **Patterns**:
    - Edit existing patterns or create new ones within the `patterns` directory.

- **Custom blocks**:
  - A separate instruction can be found [here](/docs/custom-blocks/README.md).
