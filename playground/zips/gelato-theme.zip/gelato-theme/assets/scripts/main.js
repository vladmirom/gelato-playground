console.log('Hello from main.js');
