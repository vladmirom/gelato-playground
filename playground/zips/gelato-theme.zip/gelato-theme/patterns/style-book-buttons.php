<?php
/**
 * Title: Style Book Buttons
 * Slug: gelato-theme/buttons
 * Categories: style-book
 */
?>

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
  <!-- wp:spacer {"height":"50px"} -->
  <div style="height:50px" aria-hidden="true" class="wp-block-spacer"></div>
  <!-- /wp:spacer -->

  <!-- wp:heading -->
  <h2 class="wp-block-heading">Buttons</h2>
  <!-- /wp:heading -->

  <!-- wp:columns -->
  <div class="wp-block-columns">
    <!-- wp:column {"width":"100%"} -->
    <div class="wp-block-column" style="flex-basis:100%">
      <!-- wp:columns -->
      <div class="wp-block-columns">
        <!-- wp:column -->
        <div class="wp-block-column">
          <!-- wp:heading {"level":4} -->
          <h4 class="wp-block-heading">Button Primary</h4>
          <!-- /wp:heading -->

          <!-- wp:buttons -->
          <div class="wp-block-buttons">
            <!-- wp:button {"className":"is-style-fill"} -->
            <div class="wp-block-button is-style-fill"><a class="wp-block-button__link wp-element-button">Primary</a></div>
            <!-- /wp:button -->

            <!-- wp:button {"className":"is-style-outline"} -->
            <div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button">Primary Outline</a></div>
            <!-- /wp:button -->
          </div>
          <!-- /wp:buttons -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column -->
        <div class="wp-block-column">
          <!-- wp:heading {"level":4} -->
          <h4 class="wp-block-heading">Button Secondary</h4>
          <!-- /wp:heading -->

          <!-- wp:buttons -->
          <div class="wp-block-buttons">
            <!-- wp:button {"className":"is-style-secondary"} -->
            <div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">Secondary</a></div>
            <!-- /wp:button -->

            <!-- wp:button {"className":"is-style-secondary-outline"} -->
            <div class="wp-block-button is-style-secondary-outline"><a class="wp-block-button__link wp-element-button">Secondary Outline</a></div>
            <!-- /wp:button -->
          </div>
          <!-- /wp:buttons -->
        </div>
        <!-- /wp:column -->
      </div>
      <!-- /wp:columns -->
    </div>
    <!-- /wp:column -->
  </div>
  <!-- /wp:columns -->

  <!-- wp:spacer {"height":"50px"} -->
  <div style="height:50px" aria-hidden="true" class="wp-block-spacer"></div>
  <!-- /wp:spacer -->
</div>
<!-- /wp:group -->
