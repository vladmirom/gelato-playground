<?php
/**
 * Title: Footer
 * Slug: gelato-theme/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 */
?>
