<?php
/**
 * Title: Style Book Colors
 * Slug: gelato-theme/colors
 * Categories: style-book
 */
?>

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:spacer {"height":"50px"} -->
	<div style="height:50px" aria-hidden="true" class="wp-block-spacer"></div>
	<!-- /wp:spacer -->

	<!-- wp:heading -->
	<h2 class="wp-block-heading">Colors</h2>
	<!-- /wp:heading -->

	<!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"grid","columnCount":"3","minimumColumnWidth":null}} -->
	<div class="wp-block-group">
		<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"backgroundColor":"primary","textColor":"white","layout":{"type":"default"}} -->
		<div class="wp-block-group has-white-color has-primary-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--10)">
			<!-- wp:code -->
			<pre class="wp-block-code"><code>--wp--preset--color--primary</code></pre>
			<!-- /wp:code -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"backgroundColor":"secondary","textColor":"white","layout":{"type":"default"}} -->
		<div class="wp-block-group has-white-color has-secondary-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--10)">
			<!-- wp:code -->
			<pre class="wp-block-code"><code>--wp--preset--color--secondary</code></pre>
			<!-- /wp:code -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"backgroundColor":"tertiary","textColor":"black","layout":{"type":"default"}} -->
		<div class="wp-block-group has-black-color has-tertiary-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--10)">
			<!-- wp:code -->
			<pre class="wp-block-code"><code>--wp--preset--color--tertiary</code></pre>
			<!-- /wp:code -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"backgroundColor":"quaternary","textColor":"black","layout":{"type":"default"}} -->
		<div class="wp-block-group has-black-color has-quaternary-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--10)">
			<!-- wp:code -->
			<pre class="wp-block-code"><code>--wp--preset--color--quaternary</code></pre>
			<!-- /wp:code -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"backgroundColor":"quinary","textColor":"black","layout":{"type":"default"}} -->
		<div class="wp-block-group has-black-color has-quinary-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--10)">
			<!-- wp:code -->
			<pre class="wp-block-code"><code>--wp--preset--color--quinary</code></pre>
			<!-- /wp:code -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"backgroundColor":"black","textColor":"white","layout":{"type":"default"}} -->
		<div class="wp-block-group has-white-color has-black-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--10)">
			<!-- wp:code -->
			<pre class="wp-block-code"><code>--wp--preset--color--black</code></pre>
			<!-- /wp:code -->
		</div>
		<!-- /wp:group -->

		<!-- wp:columns {"style":{"border":{"width":"1px"}},"borderColor":"black"} -->
		<div class="wp-block-columns has-border-color has-black-border-color" style="border-width:1px">
			<!-- wp:column {"width":"100%","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}}} -->
			<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);flex-basis:100%">
				<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"backgroundColor":"white","textColor":"black","layout":{"type":"default"}} -->
				<div class="wp-block-group has-black-color has-white-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--10)">
					<!-- wp:code -->
					<pre class="wp-block-code"><code>--wp--preset--color--white</code></pre>
					<!-- /wp:code -->
				</div>
				<!-- /wp:group -->
			</div>
			<!-- /wp:column -->
		</div>
		<!-- /wp:columns -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
