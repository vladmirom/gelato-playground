<?php
/**
 * Title: Style Book Gradients
 * Slug: gelato-theme/gradients
 * Categories: style-book
 */
?>

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:spacer {"height":"50px"} -->
	<div style="height:50px" aria-hidden="true" class="wp-block-spacer"></div>
	<!-- /wp:spacer -->

	<!-- wp:heading -->
	<h2 class="wp-block-heading">Gradients</h2>
	<!-- /wp:heading -->

	<!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"grid","columnCount":"1","minimumColumnWidth":null}} -->
	<div class="wp-block-group">
		<!-- wp:group {"style":{"elements":{"link":{"color":{"text":"var:preset|color|black"}}},"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|10","right":"var:preset|spacing|10"}}},"textColor":"black","gradient":"lily-to-white-to-lily","layout":{"type":"default"}} -->
		<div class="wp-block-group has-black-color has-lily-to-white-to-lily-gradient-background has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--10)">
			<!-- wp:code -->
			<pre class="wp-block-code"><code>--wp--preset--gradient--lily-to-white-to-lily</code></pre>
			<!-- /wp:code -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
