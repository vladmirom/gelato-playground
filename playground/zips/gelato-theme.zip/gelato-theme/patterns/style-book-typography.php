<?php
/**
 * Title: Style Book Typography
 * Slug: gelato-theme/typography
 * Categories: style-book
 */
?>

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:spacer {"height":"50px"} -->
	<div style="height:50px" aria-hidden="true" class="wp-block-spacer"></div>
	<!-- /wp:spacer -->

	<!-- wp:heading -->
	<h2 class="wp-block-heading">Typography</h2>
	<!-- /wp:heading -->

	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":1} -->
			<h1 class="wp-block-heading">Headline 1</h1>
			<!-- /wp:heading -->

			<!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"italic","fontWeight":"500"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}}},"textColor":"secondary","fontFamily":"eb-garamond"} -->
			<h1 class="wp-block-heading has-secondary-color has-text-color has-link-color has-eb-garamond-font-family" style="font-style:italic;font-weight:500">Headline 1</h1>
			<!-- /wp:heading -->

			<!-- wp:heading -->
			<h2 class="wp-block-heading">Headline 2</h2>
			<!-- /wp:heading -->

			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Headline 3</h3>
			<!-- /wp:heading -->

			<!-- wp:heading {"level":4} -->
			<h4 class="wp-block-heading">Headline 4</h4>
			<!-- /wp:heading -->

			<!-- wp:heading {"level":5} -->
			<h5 class="wp-block-heading">Headline 5</h5>
			<!-- /wp:heading -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Default Paragraph Style.</h3>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"style":{"layout":{"columnSpan":1,"rowSpan":1}},"fontSize":"medium"} -->
			<p class="has-medium-font-size"><strong>Lorem ipsum dolor sit amet</strong>, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
			<!-- /wp:paragraph -->

			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Large Paragraph Style.</h3>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"style":{"layout":{"columnSpan":1,"rowSpan":1}},"fontSize":"large"} -->
			<p class="has-large-font-size"><strong>Lorem ipsum dolor sit amet</strong>, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
			<!-- /wp:paragraph -->

			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Small Paragraph Style.</h3>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"style":{"layout":{"columnSpan":1,"rowSpan":1}},"fontSize":"small"} -->
			<p class="has-small-font-size"><strong>Lorem ipsum dolor sit amet</strong>, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
			<!-- /wp:paragraph -->

			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading">Link Style.</h3>
			<!-- /wp:heading -->

			<!-- wp:paragraph -->
			<p><a href="/">Lorem ipsum dolor sit amet, consectetur</a></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
